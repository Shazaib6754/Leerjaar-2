import { client } from "./openai.js";
export async function analyzeFile(code) {
    const response = await client.chat.completions.create({
        model: "gpt-4.1",
        messages: [
            { role: "system", content: "Je bent een code-analyzer. Vind problemen en verbeteringen." },
            { role: "user", content: code }
        ]
    });
    return response.choices[0].message.content;
}