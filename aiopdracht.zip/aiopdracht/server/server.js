import express from "express";
import multer from "multer";
import cors from "cors";
import fs from "fs";
import path from "path";
import AdmZip from "adm-zip";
import { analyzeFile } from "./analyze.js";
import { improveCode } from "./improve.js";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// Frontend statisch serveren
app.use(express.static(path.join(__dirname, "../frontend")));

// Root route → index.html
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/index.html"));
});

const upload = multer({ dest: "server/uploads/" });

app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const filePath = req.file.path;
    const originalName = req.file.originalname;
    let codeFiles = [];

    // Check of het een zip is
    if (originalName.endsWith(".zip")) {
      const zip = new AdmZip(filePath);
      zip.extractAllTo("server/uploads/unpacked", true);
      zip.getEntries().forEach(entry => {
        if (!entry.isDirectory) {
          const p = `server/uploads/unpacked/${entry.entryName}`;
          codeFiles.push(p);
        }
      });
    } else {
      codeFiles.push(filePath);
    }

    // Zorg dat reports map bestaat
    const reportsDir = path.join(__dirname, "reports");
    if (!fs.existsSync(reportsDir)) {
      fs.mkdirSync(reportsDir, { recursive: true });
    }

    let results = [];
    for (let file of codeFiles) {
      const code = fs.readFileSync(file, "utf8");

      let analysis, improvement;
      try {
        // Probeer echte AI-analyse
        analysis = await analyzeFile(code);
        improvement = await improveCode(code);
      } catch (err) {
        // Als AI faalt (quota/key probleem), geef mock output
        console.error("AI-analyse mislukt:", err.message);
        analysis = "Testanalyse: AI-aanroep overgeslagen (quota of API-key probleem)";
        improvement = "Verbeterde code: AI-aanroep overgeslagen";
      }

      const report = {
        file: path.basename(file),
        analysis,
        improved_code: improvement,
        timestamp: new Date().toISOString()
      };

      const reportPath = path.join(reportsDir, `${Date.now()}_${path.basename(file)}.json`);
      fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));

      results.push(report);
    }

    res.json({ status: "ok", results });
  } catch (err) {
    console.error("Upload endpoint error:", err);
    res.status(500).json({ status: "error", message: err.message });
  }
});

app.listen(3000, () => console.log("Server draait op http://localhost:3000"));
