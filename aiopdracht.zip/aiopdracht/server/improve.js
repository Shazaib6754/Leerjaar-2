import { client } from "./openai.js";
export async function improveCode(code) {
    const response = await client.chat.completions.create({
        model: "gpt-4.1",
        messages: [
            { role: "system", content: "Verbeter deze code volgens best practices. Geef alleen code terug." },
            { role: "user", content: code }
        ]
    });
    return response.choices[0].message.content;
}